var data=require("../../../DATA/Colleges");

names=[];
for(let i=0;i<Object.keys(data.Name).length;i++){
    names.push(names[i]);
}

names.forEach((e) => document.getElementById("display_name").textContent+=`${e}`);
