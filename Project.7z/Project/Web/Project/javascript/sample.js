var data=require('../../../DATA/Colleges.json');

names=[];

for(let i=0;i<Object.keys(data.Name).length;i++){
    console.log(`Working on: ${i}`);
    names.push(data.Name[i]);
}

// noinspection JSValidateTypes
//document.querySelector("#display_name").textContent=names;

names.forEach((e) => console.log(e));


document.querySelector("#display_name").innerHTML=`<li>${Math.random()}</li>`;