from numpy.linalg import norm as euclidean
from numpy import array as array


class Algorithms(object):

    def __init__(self):
        pass

    def euclideanDistance(self,a):
        c=[]
        res=[]
        z=0
        while(len(a)>z):
            analysis=a.copy()
            del analysis[z]
            for i in analysis:
                res.append(euclidean(array(a[z])-array(i)))
            c.append(tuple( [ a[z],analysis[res.index(min(res))]]))
            res.clear()
            z+=1
        return c

    def findLocation(self,gps_dd,all_coordinates_dd):
        """
        :param gps_dd: Coordinates in Decimal Degree (tuple)
        :param all_coordinates_dd: list type required (list)
        :return: Shortest Path (tuple)
        """
        c=[]
        a=all_coordinates_dd.copy()
        for i in list(all_coordinates_dd):
            c.append(euclidean(array(gps_dd)-array(i)))
        return a[a.index(min(c))]


    def binarySearch(self,arr,k):
        """
        O(log * n)
        :param arr: Sorted Array
        :param k: Key for Selection
        :return: Index
        """
        lo=0
        hi=len(arr)-1
        while(hi>=lo):
            mid=(hi+lo)//2
            if(arr[mid] == k):
                return mid
            elif(arr[mid]>k):
                hi-=1
            elif(arr[mid]<k):
                lo-=1
            else:
                return None
